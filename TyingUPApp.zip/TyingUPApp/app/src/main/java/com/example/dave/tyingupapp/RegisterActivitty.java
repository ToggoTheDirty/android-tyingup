package com.example.dave.tyingupapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class RegisterActivitty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_activitty);


//
//        startIntent.putExtra("paramName", strName);
//        startIntent.putExtra("paramEmail", strEmail);
//        startIntent.putExtra("paramPassword", strPassword);
//        startIntent.putExtra("paramCPassword", strCPassword);
        TextView registerTxt = (TextView)findViewById(R.id.registerTxt);
        String strParam = "";


        if(getIntent().hasExtra("paramName")){

            strParam = registerTxt.getText().toString() + getIntent().getExtras().get("paramName");

            registerTxt.setText(strParam);
        }


        if(getIntent().hasExtra("paramEmail")){

            strParam = registerTxt.getText().toString() + getIntent().getExtras().get("paramEmail");

            registerTxt.setText(strParam);
        }


        if(getIntent().hasExtra("paramPassword")){
            strParam = registerTxt.getText().toString() + getIntent().getExtras().get("paramPassword");

            registerTxt.setText(strParam);

        }


        if(getIntent().hasExtra("paramCPassword")){

            strParam = registerTxt.getText().toString() + getIntent().getExtras().get("paramCPassword");

            registerTxt.setText(strParam);
        }
    }

}

class RestOperation extends AsyncTask<String, Void, Void> {


    HttpC

    @Override
    protected Void doInBackground(String... strings) {
        return null;
    }

    @Override
    protected void onPreExecute(){
        super .onPreExecute();
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
    }
}
