package com.example.dave.tyingupapp;

import android.os.AsyncTask;

public class RestOperation extends AsyncTask<String, Void, Void> {


    final Clie httpClient = new DefaultHttpC

    @Override
    protected Void doInBackground(String... strings) {
        return null;
    }

    @Override
    protected void onPreExecute(){
        super .onPreExecute();
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
    }
}
