package com.example.dave.tyingupapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button regBtn = (Button)findViewById(R.id.regBtn);
        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                create intent to pass values to other activity
                Intent startIntent = new Intent(getApplicationContext(), RegisterActivitty.class);

//                get values from input text field
                TextView nameTxt = (TextView)findViewById(R.id.nameTxt);
                TextView emailTxt = (TextView)findViewById(R.id.emailTxt);
                TextView passwordTxt = (TextView)findViewById(R.id.passwordTxt);
                TextView cpasswordTxt = (TextView)findViewById(R.id.cpasswordTxt);

                String strName = nameTxt.getText().toString();
                String strEmail = emailTxt.getText().toString();
                String strPassword = passwordTxt.getText().toString();
                String strCPassword = cpasswordTxt.getText().toString();

//              pass values from this activity to other
                startIntent.putExtra("paramName", strName);
                startIntent.putExtra("paramEmail", strEmail);
                startIntent.putExtra("paramPassword", strPassword);
                startIntent.putExtra("paramCPassword", strCPassword);

                startActivity(startIntent);
            }
        });
    }
}
